var __mainPageFrameReady__=window.__mainPageFrameReady__||function(){};
var __pageFrameStartTime__=__pageFrameStartTime__||Date.now(); 
var __webviewId__=__webviewId__;
var __layer__='view';
var __maAppCode__=__maAppCode__||{}; 
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false};



/* maml-transpiler v23.3.0 2023-03-29 16:31:41 */
window.__maml_transpiler_version__='v23.3.0'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'mai']);
      Z([[7],[3,"autoplay"]]);
      Z([3,'clickButton']);
      Z([[7],[3,"circular"]]);
      Z([3,'swiper']);
      Z([[7],[3,"duration"]]);
      Z([[7],[3,"easingFunction"]]);
      Z([[7],[3,"indicatorActiveColor"]]);
      Z([[7],[3,"indicatorColor"]]);
      Z([[7],[3,"interval"]]);
      Z([[7],[3,"vertical"]]);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([3,' id']);
      Z([3,'idcard']);
      Z([3,'widthFix']);
      Z([[7],[3,"fronts"]]);
      Z([3,'id']);
      Z([[7],[3,"backs"]]);
      Z([3,'information']);
      Z([3,'holder']);
      Z([3,'title']);
      Z([3,'ሙሉ ስም']);
      Z([3,'info']);
      Z([11,[[7],[3,"fullName_amh"]]]);
      Z([3,'breakLine']);
      Z([3,'Full Name']);
      Z([11,[[7],[3,"fullName_eng"]]]);
      Z([3,'የትውልድ ቀን']);
      Z([11,[[7],[3,"dob_et"]]]);
      Z([3,'Date of Birth']);
      Z([11,[[7],[3,"dob_eng"]]]);
      Z([3,'ጾታ / Sex']);
      Z([11,[[7],[3,"sex_amh"]],[3,' / '],[[7],[3,"sex_eng"]]]);
      Z([3,'ስልክ ቁጥር / Phone Number']);
      Z([11,[[7],[3,"phone"]]]);
      Z([3,'ወረዳ / Woreda']);
      Z([11,[[7],[3,"woreda_amh"]],[3,' / '],[[7],[3,"woreda_eng"]]]);
      Z([3,'ክ/ከተማ / Subcity']);
      Z([11,[[7],[3,"zone_amh"]],[3,' / '],[[7],[3,"zone_eng"]]]);
      Z([3,'ዜግነት / Citizenship']);
      Z([11,[[7],[3,"citizenship_amh"]],[3,' / '],[[7],[3,"citizenship_Eng"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'con']);
      Z([3,'imageholder']);
      Z([3,'id-front-img']);
      Z([3,'widthFix']);
      Z([[7],[3,"backs"]]);
      Z([3,'bottomContainer']);
      Z([3,'toggleId']);
      Z([3,'toggle-btn']);
      Z([3,'']);
      Z([3,'View Front Side']);
      Z([3,'Download']);
      Z([3,'downloadImg']);
      Z([3,'downloadIcon']);
      Z([3,'black']);
      Z([3,'normal']);
      Z([3,'download'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'con']);
      Z([3,'imageholder']);
      Z([3,'id-front-img']);
      Z([3,'widthFix']);
      Z([[7],[3,"fronts"]]);
      Z([3,'bottomContainer']);
      Z([3,'toggleId']);
      Z([3,'toggle-btn']);
      Z([3,'']);
      Z([3,'View Back Side']);
      Z([3,'downloadImg']);
      Z([3,'downloadIcon']);
      Z([3,'black']);
      Z([3,'normal']);
      Z([3,'download'])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'main']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px; margin-top: -200px;']);
      Z([[2,"!"],[[6],[[7],[3,"userData"]],[3,"nickName"]]]);
      Z([3,'applyH5Token']);
      Z([3,'true']);
      Z([[7],[3,"loading"]]);
      Z([3,'margin-top: 30px; background-color:#09384f;box-shadow: 0 0 10px rgba(4, 38, 78, 0.7);']);
      Z([3,'primary']);
      Z([3,'Sign In With Telebirr']);
      Z([3,'clickButton']);
      Z([3,'form']);
      Z([3,'faydaLogin']);
      Z([3,'holderF']);
      Z([3,'color: #09384f; font-weight:700']);
      Z([11,[3,'Hello '],[[6],[[7],[3,"userData"]],[3,"nickName"]]]);
      Z([3,'title']);
      Z([11,[[7],[3,"title"]]]);
      Z([3,'holder']);
      Z([3,'bindInput']);
      Z([3,'uin-input']);
      Z([3,'14']);
      Z([3,'uin']);
      Z([3,'0000-0000-0000']);
      Z([3,'idcard']);
      Z([3,'footer']);
      Z([3,'next-btn']);
      Z([3,'submit']);
      Z([[7],[3,"loading_next"]]);
      Z([3,'login-text']);
      Z([3,'Next']);
      Z([[2,"!"],[[7],[3,"failed"]]]);
      Z([3,'error']);
      Z([3,'alert']);
      Z([3,'t']);
      Z([3,'We Couldn\x27t find your ID.']);
      Z([3,'ta']);
      Z([3,'Please Click on Register button to Register']);
      Z([3,'registerButton']);
      Z([3,'register-btn']);
      Z([3,'Register'])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'top-content']);
      Z([3,'imageBox']);
      Z([3,'profile-pic']);
      Z([3,'aspectFill']);
      Z([[7],[3,"image"]]);
      Z([3,'full-name']);
      Z([11,[[7],[3,"fullName"]]]);
      Z([3,'details']);
      Z([[2,'?:'],[[7],[3,"verified"]],[1,"success"],[1,"cancel"]]);
      Z([3,'verified-txt']);
      Z([11,[[2,'?:'],[[7],[3,"verified"]],[1,"Verified"],[1,"Not verified"]]]);
      Z([3,'mid-content']);
      Z([3,'qrBox']);
      Z([3,'qr-code-img']);
      Z([3,'aspectFit']);
      Z([[7],[3,"QRCodes"]]);
      Z([3,'footer']);
      Z([3,'detail']);
      Z([3,'cardInfo']);
      Z([3,'Card Infromation']);
      Z([3,'logout']);
      Z([3,'']);
      Z([3,'mini']);
      Z([3,'Logout'])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'https://register.fayda.et/#/eng'])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/detail/detail.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oC=_ctn("view");_setAttr(z,oC,'class',0,e,s,gg);var oD=_setAttrs(z,"swiper",["autoplay",1,"bindtap",1,"circular",2,"class",3,"duration",4,"easingFunction",5,"indicatorActiveColor",6,"indicatorColor",7,"interval",8,"vertical",9],e,s,gg);var oE=_cvn();var oF=function(oJ,oI,oH,gg){var oL=_ctn("swiper-item");var oM=_setAttrs(z,"image",["class",13,"id",1,"mode",2,"src",3],oJ,oI,gg);_ac(oL,oM);_ac(oH,oL);var oN=_ctn("swiper-item");var oO=_setAttrs(z,"image",["id",14,"mode",1,"class",3,"src",4],oJ,oI,gg);_ac(oN,oO);_ac(oH,oN);return oH;};_2(z,11,oF,e,s,gg,oE,"item","index",'*this');_ac(oD,oE);_ac(oC,oD);var oP=_ctn("view");_setAttr(z,oP,'class',19,e,s,gg);var oQ=_ctn("view");_setAttr(z,oQ,'class',20,e,s,gg);var oR=_ctn("text");_setAttr(z,oR,'class',21,e,s,gg);var oS=_o(z,22,e,s,gg);_ac(oR,oS);_ac(oQ,oR);var oT=_ctn("text");_setAttr(z,oT,'class',23,e,s,gg);var oU=_o(z,24,e,s,gg);_ac(oT,oU);_ac(oQ,oT);_ac(oP,oQ);var oV=_ctn("View");_setAttr(z,oV,'class',25,e,s,gg);_ac(oP,oV);var oW=_ctn("view");_setAttr(z,oW,'class',20,e,s,gg);var oX=_ctn("text");_setAttr(z,oX,'class',21,e,s,gg);var oY=_o(z,26,e,s,gg);_ac(oX,oY);_ac(oW,oX);var oZ=_ctn("text");_setAttr(z,oZ,'class',23,e,s,gg);var oa=_o(z,27,e,s,gg);_ac(oZ,oa);_ac(oW,oZ);_ac(oP,oW);var ob=_ctn("View");_setAttr(z,ob,'class',25,e,s,gg);_ac(oP,ob);var oc=_ctn("view");_setAttr(z,oc,'class',20,e,s,gg);var od=_ctn("text");_setAttr(z,od,'class',21,e,s,gg);var oe=_o(z,28,e,s,gg);_ac(od,oe);_ac(oc,od);var of=_ctn("text");_setAttr(z,of,'class',23,e,s,gg);var og=_o(z,29,e,s,gg);_ac(of,og);_ac(oc,of);_ac(oP,oc);var oh=_ctn("View");_setAttr(z,oh,'class',25,e,s,gg);_ac(oP,oh);var oi=_ctn("view");_setAttr(z,oi,'class',20,e,s,gg);var oj=_ctn("text");_setAttr(z,oj,'class',21,e,s,gg);var ok=_o(z,30,e,s,gg);_ac(oj,ok);_ac(oi,oj);var ol=_ctn("text");_setAttr(z,ol,'class',23,e,s,gg);var om=_o(z,31,e,s,gg);_ac(ol,om);_ac(oi,ol);_ac(oP,oi);var on=_ctn("View");_setAttr(z,on,'class',25,e,s,gg);_ac(oP,on);var oo=_ctn("view");_setAttr(z,oo,'class',20,e,s,gg);var op=_ctn("text");_setAttr(z,op,'class',21,e,s,gg);var oq=_o(z,32,e,s,gg);_ac(op,oq);_ac(oo,op);var or=_ctn("text");_setAttr(z,or,'class',23,e,s,gg);var os=_o(z,33,e,s,gg);_ac(or,os);_ac(oo,or);_ac(oP,oo);var ot=_ctn("View");_setAttr(z,ot,'class',25,e,s,gg);_ac(oP,ot);var ou=_ctn("view");_setAttr(z,ou,'class',20,e,s,gg);var ov=_ctn("text");_setAttr(z,ov,'class',21,e,s,gg);var ow=_o(z,34,e,s,gg);_ac(ov,ow);_ac(ou,ov);var ox=_ctn("text");_setAttr(z,ox,'class',23,e,s,gg);var oy=_o(z,35,e,s,gg);_ac(ox,oy);_ac(ou,ox);_ac(oP,ou);var oz=_ctn("View");_setAttr(z,oz,'class',25,e,s,gg);_ac(oP,oz);var o_=_ctn("view");_setAttr(z,o_,'class',20,e,s,gg);var oAB=_ctn("text");_setAttr(z,oAB,'class',21,e,s,gg);var oBB=_o(z,36,e,s,gg);_ac(oAB,oBB);_ac(o_,oAB);var oCB=_ctn("text");_setAttr(z,oCB,'class',23,e,s,gg);var oDB=_o(z,37,e,s,gg);_ac(oCB,oDB);_ac(o_,oCB);_ac(oP,o_);var oEB=_ctn("View");_setAttr(z,oEB,'class',25,e,s,gg);_ac(oP,oEB);var oFB=_ctn("view");_setAttr(z,oFB,'class',20,e,s,gg);var oGB=_ctn("text");_setAttr(z,oGB,'class',21,e,s,gg);var oHB=_o(z,38,e,s,gg);_ac(oGB,oHB);_ac(oFB,oGB);var oIB=_ctn("text");_setAttr(z,oIB,'class',23,e,s,gg);var oJB=_o(z,39,e,s,gg);_ac(oIB,oJB);_ac(oFB,oIB);_ac(oP,oFB);var oKB=_ctn("View");_setAttr(z,oKB,'class',25,e,s,gg);_ac(oP,oKB);var oLB=_ctn("view");_setAttr(z,oLB,'class',20,e,s,gg);var oMB=_ctn("text");_setAttr(z,oMB,'class',21,e,s,gg);var oNB=_o(z,40,e,s,gg);_ac(oMB,oNB);_ac(oLB,oMB);var oOB=_ctn("text");_setAttr(z,oOB,'class',23,e,s,gg);var oPB=_o(z,41,e,s,gg);_ac(oOB,oPB);_ac(oLB,oOB);_ac(oP,oLB);_ac(oC,oP);_ac(r,oC);
    return r;
  };
  e_["./pages/detail/detail.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/id_back/id_back.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var oRB=_ctn("view");_setAttr(z,oRB,'class',0,e,s,gg);var oSB=_ctn("view");_setAttr(z,oSB,'class',1,e,s,gg);var oTB=_setAttrs(z,"image",["class",2,"mode",1,"src",2],e,s,gg);_ac(oSB,oTB);_ac(oRB,oSB);var oUB=_ctn("view");_setAttr(z,oUB,'class',5,e,s,gg);var oVB=_setAttrs(z,"button",["bind:tap",6,"class",1,"size",2],e,s,gg);var oWB=_ctn("text");var oXB=_o(z,9,e,s,gg);_ac(oWB,oXB);_ac(oVB,oWB);_ac(oUB,oVB);var oYB=_ctn("text");var oZB=_o(z,10,e,s,gg);_ac(oYB,oZB);_ac(oUB,oYB);var oaB=_setAttrs(z,"icon",["bind:tap",11,"class",1,"color",2,"size",3,"type",4],e,s,gg);_ac(oUB,oaB);_ac(oRB,oUB);_ac(r,oRB);
    return r;
  };
  e_["./pages/id_back/id_back.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  d_["./pages/id_front/id_front.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var ocB=_ctn("view");_setAttr(z,ocB,'class',0,e,s,gg);var odB=_ctn("view");_setAttr(z,odB,'class',1,e,s,gg);var oeB=_setAttrs(z,"image",["class",2,"mode",1,"src",2],e,s,gg);_ac(odB,oeB);_ac(ocB,odB);var ofB=_ctn("view");_setAttr(z,ofB,'class',5,e,s,gg);var ogB=_setAttrs(z,"button",["bind:tap",6,"class",1,"size",2],e,s,gg);var ohB=_ctn("text");var oiB=_o(z,9,e,s,gg);_ac(ohB,oiB);_ac(ogB,ohB);_ac(ofB,ogB);var ojB=_setAttrs(z,"icon",["bind:tap",10,"class",1,"color",2,"size",3,"type",4],e,s,gg);_ac(ofB,ojB);_ac(ocB,ofB);_ac(r,ocB);
    return r;
  };
  e_["./pages/id_front/id_front.maml"]={f:m2,j:[],i:[],ti:[],ic:[]};

  d_["./pages/index/index.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var olB=_ctn("view");_setAttr(z,olB,'class',0,e,s,gg);var omB=_setAttrs(z,"image",["mode",1,"src",1,"style",2],e,s,gg);_ac(olB,omB);var onB=_cvn();if(_o(z,4,e,s,gg)){onB.maVkey=1;var ooB=_setAttrs(z,"button",["bind:tap",5,"hoverStopPropagation",1,"loading",2,"style",3,"type",4],e,s,gg);var oqB=_o(z,10,e,s,gg);_ac(ooB,oqB);_ac(onB,ooB);}else{onB.maVkey=2;var orB=_setAttrs(z,"form",["bindsubmit",11,"class",1,"id",2],e,s,gg);var otB=_ctn("view");_setAttr(z,otB,'class',14,e,s,gg);var ouB=_ctn("text");_setAttr(z,ouB,'style',15,e,s,gg);var ovB=_o(z,16,e,s,gg);_ac(ouB,ovB);_ac(otB,ouB);var owB=_ctn("text");_setAttr(z,owB,'class',17,e,s,gg);var oxB=_o(z,18,e,s,gg);_ac(owB,oxB);_ac(otB,owB);_ac(orB,otB);var oyB=_ctn("view");_setAttr(z,oyB,'class',19,e,s,gg);var ozB=_setAttrs(z,"input",["bindinput",20,"class",1,"maxlength",2,"name",3,"placeholder",4,"type",5],e,s,gg);_ac(oyB,ozB);_ac(orB,oyB);var o_B=_ctn("view");_setAttr(z,o_B,'class',26,e,s,gg);var oAC=_setAttrs(z,"button",["bindsubmit",6,"class",21,"formType",22,"loading",23],e,s,gg);var oBC=_ctn("text");_setAttr(z,oBC,'class',30,e,s,gg);var oCC=_o(z,31,e,s,gg);_ac(oBC,oCC);_ac(oAC,oBC);_ac(o_B,oAC);_ac(orB,o_B);_ac(onB,orB);}_ac(olB,onB);var oDC=_cvn();if(_o(z,32,e,s,gg)){oDC.maVkey=1;var oEC=_ctn("view");_setAttr(z,oEC,'class',33,e,s,gg);var oGC=_ctn("view");_setAttr(z,oGC,'class',34,e,s,gg);var oHC=_ctn("text");_setAttr(z,oHC,'class',35,e,s,gg);var oIC=_o(z,36,e,s,gg);_ac(oHC,oIC);_ac(oGC,oHC);var oJC=_ctn("text");_setAttr(z,oJC,'class',37,e,s,gg);var oKC=_o(z,38,e,s,gg);_ac(oJC,oKC);_ac(oGC,oJC);_ac(oEC,oGC);var oLC=_setAttrs(z,"button",["bind:tap",39,"class",1],e,s,gg);var oMC=_ctn("text");_setAttr(z,oMC,'class',30,e,s,gg);var oNC=_o(z,41,e,s,gg);_ac(oMC,oNC);_ac(oLC,oMC);_ac(oEC,oLC);_ac(oDC,oEC);} _ac(olB,oDC);_ac(r,olB);
    return r;
  };
  e_["./pages/index/index.maml"]={f:m3,j:[],i:[],ti:[],ic:[]};

  d_["./pages/profile/profile.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var oPC=_ctn("view");_setAttr(z,oPC,'class',0,e,s,gg);var oQC=_ctn("view");_setAttr(z,oQC,'class',1,e,s,gg);var oRC=_ctn("view");_setAttr(z,oRC,'class',2,e,s,gg);var oSC=_setAttrs(z,"image",["class",3,"mode",1,"src",2],e,s,gg);_ac(oRC,oSC);_ac(oQC,oRC);var oTC=_ctn("text");_setAttr(z,oTC,'class',6,e,s,gg);var oUC=_o(z,7,e,s,gg);_ac(oTC,oUC);_ac(oQC,oTC);var oVC=_ctn("view");_setAttr(z,oVC,'class',8,e,s,gg);var oWC=_ctn("icon");_setAttr(z,oWC,'type',9,e,s,gg);_ac(oVC,oWC);var oXC=_ctn("text");_setAttr(z,oXC,'class',10,e,s,gg);var oYC=_o(z,11,e,s,gg);_ac(oXC,oYC);_ac(oVC,oXC);_ac(oQC,oVC);_ac(oPC,oQC);var oZC=_ctn("view");_setAttr(z,oZC,'class',12,e,s,gg);var oaC=_ctn("view");_setAttr(z,oaC,'class',13,e,s,gg);var obC=_setAttrs(z,"image",["class",14,"mode",1,"src",2],e,s,gg);_ac(oaC,obC);_ac(oZC,oaC);_ac(oPC,oZC);var ocC=_ctn("view");_setAttr(z,ocC,'class',17,e,s,gg);var odC=_setAttrs(z,"button",["bind:tap",18,"class",1],e,s,gg);var oeC=_ctn("text");var ofC=_o(z,20,e,s,gg);_ac(oeC,ofC);_ac(odC,oeC);_ac(ocC,odC);_ac(oPC,ocC);var ogC=_ctn("view");_setAttr(z,ogC,'class',21,e,s,gg);var ohC=_setAttrs(z,"button",["bind:tap",21,"class",1,"size",2],e,s,gg);var oiC=_ctn("text");var ojC=_o(z,24,e,s,gg);_ac(oiC,ojC);_ac(ohC,oiC);_ac(ogC,ohC);_ac(oPC,ogC);_ac(r,oPC);
    return r;
  };
  e_["./pages/profile/profile.maml"]={f:m4,j:[],i:[],ti:[],ic:[]};

  d_["./pages/registration/registration.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var olC=_ctn("web-view");_setAttr(z,olC,'src',0,e,s,gg);_ac(r,olC);
    return r;
  };
  e_["./pages/registration/registration.maml"]={f:m5,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

var BASE_DEVICE_WIDTH=750;
var deviceWidth=window.screen.width||375;
var isIOS=navigator.userAgent.match("iPhone");
var deviceDPR=window.devicePixelRatio||2;
var checkDeviceWidth=window.__checkDeviceWidth__||function(){
  var newDeviceDPR=window.devicePixelRatio||2
  var newDeviceWidth=window.screen.width||375
  var newDeviceHeight=window.screen.height||375
  if(window.screen.orientation&&/^landscape/.test(window.screen.orientation.type||''))newDeviceWidth=newDeviceHeight
  if(newDeviceWidth!==deviceWidth||newDeviceDPR!==deviceDPR){
    deviceDPR=newDeviceDPR
    deviceWidth=newDeviceWidth
  }
}
checkDeviceWidth()
var eps=1e-4;
var transformRPX=window.__transformRpx__||function(number,newDeviceWidth){
  if(number===0)return 0;
  number=number/BASE_DEVICE_WIDTH*(newDeviceWidth||deviceWidth);
  number=Math.floor(number+eps);
  if(number===0){
    if(deviceDPR===1||!isIOS)return 1;
    else return 0.5;
  }
  return number;
}
var __COMMON_STYLESHEETS__=__COMMON_STYLESHEETS__||{}


var setCssToHead=function(file,info){
  var importedStyles={},info=info||{};
  function makeup(file,opt){
    var isPath=typeof(file)==="string";
    if(isPath&&importedStyles.hasOwnProperty(file))return "";
    if(isPath)importedStyles[file]=1;
    var contents=isPath?__COMMON_STYLESHEETS__[file]:file,res="";
    for(var i=contents.length-1;i>=0;i--){
      var content=contents[i];
      if(typeof(content)==="object"){
        var op=content[0];
        if(op===0)res=transformRPX(content[1],opt.deviceWidth)+"px"+res; // rpx
        else if(op===1)res=opt.suffix+res; // suffix
        else if(op===2)res=makeup(content[1],opt)+res; // import at the top
        else if(op===3)res=makeup(content[1],opt)+res; // import not at the top
      }else{
        res=content+res;
      }
    }
    return res;
  }
  var rewritor=function(suffix,opt,style,tFile,tInfo){
    opt=opt||{};
    suffix=suffix||"";
    opt.suffix=suffix;
    tFile=tFile||file;
    tInfo=tInfo||info;
    css=makeup(tFile,opt);
    if(!css)return;
    
    if(!style){
      var head=document.head||document.getElementsByTagName('head')[0];
      style=document.createElement('style');
      style.type='text/css';
      style.setAttribute("mass:path",tInfo.path);
      head.appendChild(style);
    }
    if(style.childNodes.length==0)style.appendChild(document.createTextNode(css));
    else style.childNodes[0].nodeValue=css;
  }
  return rewritor;
}
__maAppCode__['app.json']={"window":{"backgroundTextStyle":"dark","navigationBarBackgroundColor":"#fff","navigationBarTitleText":"","navigationBarTextStyle":"black","capsuleTheme":"light"}};

__maAppCode__['pages/detail/detail.json']={"navigationBarTitleText":"Card Information"};
__maAppCode__['pages/id_back/id_back.json']={"navigationBarTitleText":"Digital ID"};
__maAppCode__['pages/id_front/id_front.json']={"navigationBarTitleText":"Digital ID"};
__maAppCode__['pages/index/index.json']={"usingComponents":{}};
__maAppCode__['pages/profile/profile.json']={"navigationBarTitleText":"National ID"};
__maAppCode__['pages/registration/registration.json']={"navigationBarTitleText":"Preregistration","enablePullDownRefresh":false};

setCssToHead([".",[1],"container{-webkit-align-items:center;align-items:center;background-color:#fff;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,100]," 0}@font-face{font-family:barlow;src:url(common/BarlowSemiCondensed-Bold.ttf)}@font-face{font-family:nokia;src:url(common/nokiapureheadline_bold.otf)}"],{path:"./app.mass"})();
__maAppCode__['pages/detail/detail.mass']=setCssToHead([".",[1],"mai{-webkit-align-items:center;align-items:center;color:#09384f;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;font-size:14px;-webkit-justify-content:center;justify-content:center;padding:20px}\n.",[1],"info{border-radius:6px;font-size:1.5em;font-weight:520}\n.",[1],"holder{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;margin-bottom:15px;padding-left:10px}\n.",[1],"title{color:#646464;font-size:1.3em;font-weight:500}\n.",[1],"id{border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,.5)}\n.",[1],"breakLine{background-color:rgba(94,94,94,.2);color:#000;height:1.5px;margin:-5px 0 10px;width:100%}\n.",[1],"information{grid-column:1/-1;margin-top:4%;width:100%}\n.",[1],"swiper-item{justify-items:center}\n.",[1],"swiper-item,ma-image{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\nma-image{justify-self:center;margin-bottom:0;padding-bottom:0;position:-webkit-sticky;position:sticky;width:auto}\n.",[1],"cardHolder{-webkit-align-items:center;align-items:center;background-color:aqua;-webkit-justify-content:center;justify-content:center}\n.",[1],"cardHolder,.",[1],"swiper{display:-webkit-flex;display:flex;width:100%}\n.",[1],"swiper{height:300px}"],{path:"./pages/detail/detail.mass"});
__maAppCode__['pages/id_back/id_back.mass']=setCssToHead([".",[1],"con{height:100%;padding:32% 0 0;width:100%}\n.",[1],"con,.",[1],"imageholder{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center}\n.",[1],"imageholder{-webkit-transform:rotate(90deg);transform:rotate(90deg);width:140%}\n.",[1],"id-front-img{-webkit-align-items:center;align-items:center;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,.7);display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"toggle-btn{background-color:transparent;color:#09384f;font-size:1.2em;font-weight:bolder;margin:0;outline:none}\n.",[1],"toggle-btn:after{border:none}\n.",[1],"download-btn{background-color:transparent;border:none}\n.",[1],"bottomContainer,.",[1],"download-btn{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"bottomContainer{-webkit-flex-direction:column;flex-direction:column;margin:30% 0 30px;width:80%}"],{path:"./pages/id_back/id_back.mass"});
__maAppCode__['pages/id_front/id_front.mass']=setCssToHead([".",[1],"con{height:100%;padding:32% 0 0;width:100%}\n.",[1],"con,.",[1],"imageholder{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center}\n.",[1],"imageholder{-webkit-transform:rotate(90deg);transform:rotate(90deg);width:140%}\n.",[1],"id-front-img{-webkit-align-items:center;align-items:center;border-radius:10px;box-shadow:0 0 10px rgba(0,0,0,.7);display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"toggle-btn{background-color:transparent;color:#09384f;font-size:1.2em;font-weight:bolder;margin:0;outline:none}\n.",[1],"toggle-btn:after{border:none}\n.",[1],"download-btn{background-color:transparent;border:none}\n.",[1],"bottomContainer,.",[1],"download-btn{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center}\n.",[1],"bottomContainer{-webkit-flex-direction:column;flex-direction:column;margin:30% 0 30px;width:80%}"],{path:"./pages/id_front/id_front.mass"});
__maAppCode__['pages/index/index.mass']=setCssToHead(["body{height:100%;width:100%}\n.",[1],"form,.",[1],"main{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"main{background-color:#fff;-webkit-flex-direction:column;flex-direction:column;height:100%;padding:0}\n.",[1],"main,.",[1],"title{text-align:center}\n.",[1],"title{-webkit-align-self:center;align-self:center;color:#09384f;display:block;font-weight:700;margin-top:2%}\n.",[1],"holderF{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"holder,.",[1],"holderF{-webkit-align-items:center;align-items:center;-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"holder{display:block}\n.",[1],"uin-input{border:2px solid #0c4866;border-radius:6px;box-shadow:0 0 2px rgba(4,38,78,.2);color:#09384f;font-weight:600;margin:50px 0;padding:4px;width:280px}\n.",[1],"footer{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:flex-end;justify-content:flex-end}\n.",[1],"next-btn,.",[1],"next-btn:after{-webkit-align-items:center;align-items:center;background-color:transparent;border:none;border-radius:40px;height:30px;line-height:1.3;outline:none;position:fixed}\n.",[1],"next-btn{background-color:#e7e7e7}\n.",[1],"next-btn,.",[1],"register-btn{box-shadow:0 0 3px rgba(0,0,0,.7);display:-webkit-flex;display:flex}\n.",[1],"register-btn{-webkit-align-items:center;align-items:center;background-color:#c2c2c2;background-color:transparent;border-radius:40px;height:30px;margin-top:4%}\n.",[1],"errorMessage{background-color:aqua}\n.",[1],"error{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;margin-top:15%;width:100%}\n.",[1],"login-text{color:#1c5069;font-size:.8em;font-weight:700;margin-top:10%}\n.",[1],"t{margin-top:5px}\n.",[1],"ta{margin-bottom:5px;margin-top:1px}\n.",[1],"alert:before{background-color:#0c4866}\n.",[1],"alert{-webkit-animation:label-entrance .6s ease-in-out forwards;animation:label-entrance .6s ease-in-out forwards;background-color:#f85329;border-radius:4px;color:#fff;display:-webkit-flex;display:flex;display:inline-block;-webkit-flex-direction:column;flex-direction:column;font-style:bold;-webkit-justify-content:center;justify-content:center;opacity:0;width:100%}@-webkit-keyframes label-entrance{0%{opacity:0;-webkit-transform:translateY(-120px);transform:translateY(-120px)}\nto{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}@keyframes label-entrance{0%{opacity:0;-webkit-transform:translateY(-120px);transform:translateY(-120px)}\nto{opacity:1;-webkit-transform:translateY(0);transform:translateY(0)}}"],{path:"./pages/index/index.mass"});
__maAppCode__['pages/profile/profile.mass']=setCssToHead([".",[1],"box{background-color:#fff;color:#09384f;font-size:14px;height:100%;padding:5%}\n.",[1],"box,.",[1],"top-content{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"top-content{margin:0;padding:0;width:100%}\n.",[1],"mid-content{-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center;margin:0 0 10px;padding:10px 0;width:100%}\n.",[1],"footer,.",[1],"mid-content{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"footer{background-color:#09384f;border-radius:8px;color:#fff;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:start;justify-content:start;margin:0 0 8px;padding:2px;width:200px}\n.",[1],"top-bar{background-color:#028513;height:100px;margin-bottom:5%;width:100%}\n.",[1],"imageBox,.",[1],"top-bar{display:-webkit-flex;display:flex}\n.",[1],"imageBox{-webkit-align-items:center;align-items:center;background-color:#fff;border-radius:3%;box-shadow:0 0 20px rgba(0,0,0,.2);height:265px;-webkit-justify-content:center;justify-content:center;max-width:1000px;overflow:hidden;width:240px}\n.",[1],"profile-pic{-webkit-filter:brightness(90%) contrast(100%) saturate(100%);filter:brightness(90%) contrast(100%) saturate(100%);height:100%;mix-blend-mode:multiply;object-fit:cover;width:100%}\n.",[1],"full-name{color:#09384f;font-size:1.5em;font-weight:800;margin:15px 0}\n.",[1],"details{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row}\n.",[1],"details ma-icon{margin-right:10px}\n.",[1],"qrBox{-webkit-align-items:center;align-items:center;background-color:#76b5d4;display:-webkit-flex;display:flex;height:300px;-webkit-justify-content:center;justify-content:center;width:300px}\n.",[1],"qr-code-img{height:100%;object-fit:cover;width:100%}\n.",[1],"verified-txt{font-size:1.2em;text-align:center}\n.",[1],"view-id-btn{background-color:transparent;color:#09384f;font-size:1.4em;font-weight:bolder;margin:0 0 5px;outline:none}\n.",[1],"box ma-button:after,.",[1],"view-id-btn:after{border:none}\n.",[1],"footer ma-button{background-color:transparent;color:#fff;font-size:1em;font-weight:700}\n.",[1],"logout{-webkit-align-items:center;align-items:center;background-color:#b80000;border-radius:8px;color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:start;justify-content:start;margin:0 0 8px;padding:2px;width:200px}\n.",[1],"logout ma-button{background-color:transparent;color:#fff;font-size:1em;font-weight:700}"],{path:"./pages/profile/profile.mass"});
__maAppCode__['pages/registration/registration.mass']=setCssToHead([""],{path:"./pages/registration/registration.mass"});
__maAppCode__['pages/detail/detail.maml']=$gma('./pages/detail/detail.maml');
__maAppCode__['pages/id_back/id_back.maml']=$gma('./pages/id_back/id_back.maml');
__maAppCode__['pages/id_front/id_front.maml']=$gma('./pages/id_front/id_front.maml');
__maAppCode__['pages/index/index.maml']=$gma('./pages/index/index.maml');
__maAppCode__['pages/profile/profile.maml']=$gma('./pages/profile/profile.maml');
__maAppCode__['pages/registration/registration.maml']=$gma('./pages/registration/registration.maml');

__mainPageFrameReady__();
var __pageFrameEndTime__=Date.now();
